package metier;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CatalogueMetierImpl implements ICatalogueMetier {

	@Override
	public void addPersonnel(Personnel p) {
         Connection conn=SingletonConnection.getConnection();
         try {
			PreparedStatement ps=conn.prepareStatement("INSERT INTO PERSONNELS (CIN  , NOM  , PRENOM  , DATE_naiss  , ADRESSE  , EMAIL  , TEL  , CIVILTE  , NATIONNALITE , CODE_POSTAL , DEPRTEMENT  , LIEU  , SALAIRE  , POSTE  , TYPE_CONTRAT  , DATE_DEBUT_TRAVAIL  , HORAIRE  , NUM_COMPTE_BANCAIRE ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps.setInt(1,p.getCin());
		ps.setString(2, p.getNom());
		ps.setString(3, p.getPrenom());
		ps.setString(4, p.getDte_nais());
		ps.setString(5, p.getAdresse());
		ps.setString(6, p.getEmail());
		ps.setInt(7, p.getTel());
		ps.setString(8, p.getCivilite());
		ps.setString(9, p.getNationnalite());
		ps.setInt(10, p.getCode_postal());
		ps.setString(11, p.getDepartement());
		ps.setString(12, p.getLieu());
		ps.setInt(13, p.getSalaire());
		ps.setString(14, p.getPoste());
		ps.setString(15, p.getType_contrat());
		ps.setString(16,p.getDate_deb_trav());
		ps.setString(17, p.getHoraire());
		ps.setInt(18, p.getNum_compte_b());
		ps.executeUpdate();
		ps.close(); //fermeture de l'objet
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
	}

	@Override
	public List<Personnel> listPersonnels() {
		List<Personnel>  perss=new ArrayList<Personnel>();
		Connection conn=SingletonConnection.getConnection();
        try {
			PreparedStatement ps=conn.prepareStatement("SELECT * FROM PERSONNELS");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) { //pour chaque ligne on va cr�er un personnel 
				Personnel p=new Personnel();
				p.setCin(rs.getInt("CIN")); //recuperation de la valeur de colonne CIN et la mettre 
				p.setNom(rs.getString("NOM"));
				p.setPrenom(rs.getString("PRENOM"));
				p.setDte_nais(rs.getString("DATE_naiss"));
				p.setAdresse(rs.getString("ADRESSE"));
				p.setEmail(rs.getString("EMAIL")); 
				p.setTel(rs.getInt("TEL"));
				p.setCivilite(rs.getString("CIVILTE"));
				p.setNationnalite(rs.getString("NATIONNALITE"));
				p.setCode_postal(rs.getInt("CODE_POSTAL"));
				p.setDepartement(rs.getString("DEPRTEMENT"));
				p.setLieu(rs.getString("LIEU"));
				p.setSalaire(rs.getInt("SALAIRE"));
				p.setPoste(rs.getString("POSTE"));
				p.setType_contrat(rs.getString("TYPE_CONTRAT"));
				p.setDate_deb_trav(rs.getString("DATE_DEBUT_TRAVAIL"));
				p.setHoraire(rs.getString("HORAIRE"));
				p.setNum_compte_b(rs.getInt("NUM_COMPTE_BANCAIRE"));
				perss.add(p);
			}
		ps.close(); //fermeture de l'objet:cnx
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return perss;
	}

	@Override
	public List<Personnel> PersonnelsParMC(String mc) {
		List<Personnel>  perss=new ArrayList<Personnel>();
		Connection conn=SingletonConnection.getConnection();
        try {
			PreparedStatement ps=conn.prepareStatement("SELECT * FROM PERSONNELS WHERE NOM like ?");
			ps.setString(1,"%"+mc+"%");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) { //pour chaque ligne on va cr�er un personnel 
				Personnel p=new Personnel();
				p.setCin(rs.getInt("CIN")); //recuperation de la valeur de colonne CIN et la mettre 
				p.setNom(rs.getString("NOM"));
				p.setPrenom(rs.getString("PRENOM"));
				p.setDte_nais(rs.getString("DATE_naiss"));
				p.setAdresse(rs.getString("ADRESSE"));
				p.setEmail(rs.getString("EMAIL")); 
				p.setTel(rs.getInt("TEL"));
				p.setCivilite(rs.getString("CIVILTE"));
				p.setNationnalite(rs.getString("NATIONNALITE"));
				p.setCode_postal(rs.getInt("CODE_POSTAL"));
				p.setDepartement(rs.getString("DEPRTEMENT"));
				p.setLieu(rs.getString("LIEU"));
				p.setSalaire(rs.getInt("SALAIRE"));
				p.setPoste(rs.getString("POSTE"));
				p.setType_contrat(rs.getString("TYPE_CONTRAT"));
				p.setDate_deb_trav(rs.getString("DATE_DEBUT_TRAVAIL"));
				p.setHoraire(rs.getString("HORAIRE"));
				p.setNum_compte_b(rs.getInt("NUM_COMPTE_BANCAIRE"));
				perss.add(p);
			}
		ps.close(); //fermeture de l'objet:cnx
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return perss;
	}

	@Override
	public Personnel getPersonnel(int c) {
		Personnel  p=null;
		Connection conn=SingletonConnection.getConnection();
        try {
			PreparedStatement ps=conn.prepareStatement("SELECT * FROM PERSONNELS WHERE CIN like ?");
			ps.setInt(1,c);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				p=new Personnel();
				p.setCin(rs.getInt("CIN")); //recuperation de la valeur de colonne CIN et la mettre 
				p.setNom(rs.getString("NOM"));
				p.setPrenom(rs.getString("PRENOM"));
				p.setDte_nais(rs.getString("DATE_naiss"));
				p.setAdresse(rs.getString("ADRESSE"));
				p.setEmail(rs.getString("EMAIL")); 
				p.setTel(rs.getInt("TEL"));
				p.setCivilite(rs.getString("CIVILTE"));
				p.setNationnalite(rs.getString("NATIONNALITE"));
				p.setCode_postal(rs.getInt("CODE_POSTAL"));
				p.setDepartement(rs.getString("DEPRTEMENT"));
				p.setLieu(rs.getString("LIEU"));
				p.setSalaire(rs.getInt("SALAIRE"));
				p.setPoste(rs.getString("POSTE"));
				p.setType_contrat(rs.getString("TYPE_CONTRAT"));
				p.setDate_deb_trav(rs.getString("DATE_DEBUT_TRAVAIL"));
				p.setHoraire(rs.getString("HORAIRE"));
				p.setNum_compte_b(rs.getInt("NUM_COMPTE_BANCAIRE"));
			}
		ps.close(); //fermeture de l'objet:cnx
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        if (p==null) throw new RuntimeException("Personnel"+c+" introuvable");
        return p;
	}

	@Override
	public void updatePersonnel(Personnel p) {
		Connection con=SingletonConnection.getConnection();
        try {
			PreparedStatement ps=con.prepareStatement("UPDATE PERSONNELS SET  NOM=?  , PRENOM=?  , DATE_naiss=?  , ADRESSE=?  , EMAIL=?  , TEL=?  , CIVILTE=?  , NATIONNALITE=? , CODE_POSTAL=? , DEPRTEMENT=?  , LIEU=?  , SALAIRE=?  , POSTE=?  , TYPE_CONTRAT=?  , DATE_DEBUT_TRAVAIL=?  , HORAIRE=?  , NUM_COMPTE_BANCAIRE=? WHERE CIN=?");
		ps.setString(1, p.getNom());
		ps.setString(2, p.getPrenom());
		ps.setString(3,p.getDte_nais());
		ps.setString(4, p.getAdresse());
		ps.setString(5, p.getEmail());
		ps.setInt(6, p.getTel());
		ps.setString(7, p.getCivilite());
		ps.setString(8, p.getNationnalite());
		ps.setInt(9, p.getCode_postal());
		ps.setString(10, p.getDepartement());
		ps.setString(11, p.getLieu());
		ps.setInt(12, p.getSalaire());
		ps.setString(13, p.getPoste());
		ps.setString(14, p.getType_contrat());
		ps.setString(15,  p.getDate_deb_trav());
		ps.setString(16, p.getHoraire());
		ps.setInt(17, p.getNum_compte_b());
		ps.setInt(18,p.getCin());
		ps.executeUpdate();
		ps.close(); //fermeture de l'objet
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	@Override
	public void deletePersonnel(int c) {
		Connection conn=SingletonConnection.getConnection();
        try {
			PreparedStatement ps=conn.prepareStatement("DELETE FROM PERSONNELS WHERE CIN=?");
		ps.setInt(1,c);
		ps.executeUpdate();
		ps.close(); //fermeture de l'objet
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
