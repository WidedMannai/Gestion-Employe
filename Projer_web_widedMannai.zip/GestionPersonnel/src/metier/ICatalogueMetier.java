package metier;

import java.util.List;

public interface ICatalogueMetier {
	public void addPersonnel(Personnel p);
	public List<Personnel> listPersonnels();
	public List<Personnel> PersonnelsParMC(String mc);
	public Personnel getPersonnel(int c );
	public void updatePersonnel(Personnel p);
	public void deletePersonnel(int c);
	
	
	


}
