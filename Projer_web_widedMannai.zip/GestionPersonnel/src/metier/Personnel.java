package metier;

import java.io.Serializable;


public class Personnel implements Serializable {
	private int cin;
	private String nom;
	private String prenom;
	private String dte_nais;
	private String adresse;
	private String  email ;
	private int tel ;
	private String civilite;
	private String nationnalite ;
	private int code_postal ;
	private String departement ;
	private String lieu ;
	private int salaire ;
	private String poste ;
	private String type_contrat; 
	private String date_deb_trav ;
	private String horaire ;
	private int num_compte_b ;
	public int getCin() {
		return cin;
	}
	public void setCin(int cin) {
		this.cin = cin;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getDte_nais() {
		return dte_nais;
	}
	public void setDte_nais(String dte_nais) {
		this.dte_nais = dte_nais;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}
	public String getCivilite() {
		return civilite;
	}
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
	public String getNationnalite() {
		return nationnalite;
	}
	public void setNationnalite(String nationnalite) {
		this.nationnalite = nationnalite;
	}
	public int getCode_postal() {
		return code_postal;
	}
	public void setCode_postal(int code_postal) {
		this.code_postal = code_postal;
	}
	public String getDepartement() {
		return departement;
	}
	public void setDepartement(String departement) {
		this.departement = departement;
	}
	public String getLieu() {
		return lieu;
	}
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	public int getSalaire() {
		return salaire;
	}
	public void setSalaire(int salaire) {
		this.salaire = salaire;
	}
	public String getPoste() {
		return poste;
	}
	public void setPoste(String poste) {
		this.poste = poste;
	}
	public String getType_contrat() {
		return type_contrat;
	}
	public void setType_contrat(String type_contrat) {
		this.type_contrat = type_contrat;
	}
	public String getDate_deb_trav() {
		return date_deb_trav;
	}
	public void setDate_deb_trav(String date_deb_trav) {
		this.date_deb_trav = date_deb_trav;
	}
	public String getHoraire() {
		return horaire;
	}
	public void setHoraire(String horaire) {
		this.horaire = horaire;
	}
	public int getNum_compte_b() {
		return num_compte_b;
	}
	public void setNum_compte_b(int num_compte_b) {
		this.num_compte_b = num_compte_b;
	}
	
	public Personnel(int cin, String nom, String prenom, String dte_nais, String adresse, String email, int tel,
			String civilite, String nationnalite, int code_postal, String departement, String lieu, int salaire,
			String poste, String type_contrat, String date_deb_trav, String horaire, int num_compte_b) {
		super();
		this.cin = cin;
		this.nom = nom;
		this.prenom = prenom;
		this.dte_nais = dte_nais;
		this.adresse = adresse;
		this.email = email;
		this.tel = tel;
		this.civilite = civilite;
		this.nationnalite = nationnalite;
		this.code_postal = code_postal;
		this.departement = departement;
		this.lieu = lieu;
		this.salaire = salaire;
		this.poste = poste;
		this.type_contrat = type_contrat;
		this.date_deb_trav = date_deb_trav;
		this.horaire = horaire;
		this.num_compte_b = num_compte_b;
	}
	
	
	

	public Personnel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
