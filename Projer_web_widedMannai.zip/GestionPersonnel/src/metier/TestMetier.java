package metier;

import java.util.List;

public class TestMetier {

	public static void main(String[] args) {
		ICatalogueMetier metier=new CatalogueMetierImpl();
         /*  metier.addPersonnel(new Personnel("10","a","a", "1997/07/07","a","a",11,"a","a",11,"a","a",11,"a","a","1997/07/07","a",11));
            metier.addPersonnel(new Personnel("11","b","b", "1998/08/08","b","b",22,"b","b",22,"b","b",22,"b","b","1998/08/08","b",22));
            metier.addPersonnel(new Personnel("12","c","c", "1999/09/09","c","b",33,"c","c",33,"c","c",33,"c","c","1999/09/09","c",33));
            */
          /* 
		System.out.println("---------");
		 */
		List<Personnel> perss=metier.listPersonnels();
		for( Personnel p:perss) {
			System.out.println(p.getNom());
		}/*
		System.out.println("--------");
		List<Personnel> perss2=metier.PersonnelsParMC("a");
		for( Personnel p:perss2) {
			System.out.println(p.getNom());
		}

		
		*/
		
		
		
		
		
		
		
		
		
		
		
	}

}
