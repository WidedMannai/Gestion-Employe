package web;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import metier.CatalogueMetierImpl;
import metier.ICatalogueMetier;
import metier.Personnel;

/**
 * Servlet implementation class ControleurServlet2
 */
@WebServlet("/ControleurServlet2")
public class ControleurServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
private ICatalogueMetier metier;
	
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		        PersonnelModel model=new PersonnelModel();
		        request.setAttribute("model", model);	
		        String action=request.getParameter("action");
		        if (action!=null) {
		        	if(action.equals("chercher")) {
						model.setMotCle(request.getParameter("motCle"));
						List<Personnel> personnels=metier.PersonnelsParMC(model.getMotCle());
						model.setPersonnels(personnels);	
		        	}
		        	else if (action.equals("delete")) {
		        		int c=Integer.parseInt(request.getParameter("c"));
		        		metier.deletePersonnel(c);
		        		model.setPersonnels(metier.listPersonnels());		
		        	}
		        	else if (action.equals("modifier")) {
		        		int c=Integer.parseInt(request.getParameter("c"));
		        		Personnel p=metier.getPersonnel(c);
		        		model.setPersonnel(p);
		        		model.setMode("modifier");
		        		model.setPersonnels(metier.listPersonnels());		
		        	}
		        	else if (action.equals("enregistrer")) {
		        		try {
		        		model.getPersonnel().setCin(Integer.parseInt(request.getParameter("cin")));
		        		model.getPersonnel().setNom(request.getParameter("nom"));
		        		model.getPersonnel().setPrenom(request.getParameter("prenom"));
		        		model.getPersonnel().setDte_nais(request.getParameter("dte_nais"));
		        		model.getPersonnel().setAdresse(request.getParameter("adresse"));
		        		model.getPersonnel().setEmail(request.getParameter("email"));
		        		model.getPersonnel().setTel(Integer.parseInt(request.getParameter("tel")));
		        		model.getPersonnel().setCivilite(request.getParameter("civilite"));
		        		model.getPersonnel().setNationnalite(request.getParameter("nationnalite"));
		        		model.getPersonnel().setCode_postal(Integer.parseInt(request.getParameter("code_postal")));
		        		model.getPersonnel().setDepartement(request.getParameter("departement"));
		        		model.getPersonnel().setLieu(request.getParameter("lieu"));
		        		model.getPersonnel().setSalaire(Integer.parseInt(request.getParameter("salaire")));
		        		model.getPersonnel().setPoste(request.getParameter("poste"));
		        		model.getPersonnel().setType_contrat(request.getParameter("type_contrat"));
		        		model.getPersonnel().setDate_deb_trav(request.getParameter("date_deb_trav"));
		        		model.getPersonnel().setHoraire(request.getParameter("horaire"));
		        		model.getPersonnel().setNum_compte_b(Integer.parseInt(request.getParameter("num_compte_b")));
		        		model.setMode(request.getParameter("mode"));
		        		if(model.getMode().equals("ajout"))
		        		  metier.addPersonnel(model.getPersonnel());
		        		else if (model.getMode().equals("modifier"))
		        			metier.updatePersonnel(model.getPersonnel());
		        		model.setPersonnels(metier.listPersonnels());
		        	}
		        		catch(Exception e) {
		        			model.setErrors(e.getMessage());
		        		}
		        		}
		        }
				
				request.getRequestDispatcher("VuePersonnels.jsp").
				forward(request,response);
		
		}
		
	

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControleurServlet2() {
        super();
        // TODO Auto-generated constructor stub
        metier=new CatalogueMetierImpl();
        
        
        

    }

}