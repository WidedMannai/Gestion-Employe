package web;
import metier.Personnel;
import java.util.ArrayList;
import java.util.List;


public class PersonnelModel {
	
	private String motCle;
	private Personnel personnel=new Personnel();
	private List<Personnel> personnels=new ArrayList<Personnel>();
	private String errors; 
	private String mode="ajout";
	public Personnel getPersonnel() {
		return personnel;
	}
	public void setPersonnel(Personnel personnel) {
		this.personnel = personnel;
	}
	public String getMotCle() {
		return motCle;
	}
	public void setMotCle(String motCle) {
		this.motCle = motCle;
	}
	public List<Personnel> getPersonnels() {
		return personnels;
	}
	public void setPersonnels(List<Personnel> personnels) {
		this.personnels = personnels;
	}
	public String getErrors() {
		return errors;
	}
	public void setErrors(String errors) {
		this.errors = errors;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	 
	
	
	
	
	
	
	
	
	
	
	

}
